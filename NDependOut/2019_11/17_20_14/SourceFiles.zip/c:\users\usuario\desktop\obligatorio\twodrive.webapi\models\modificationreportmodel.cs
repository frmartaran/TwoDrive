﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwoDrive.WebApi.Models
{
    public class ModificationReportModel
    {
        public string Owner { get; set; }

        public int Amount { get; set; }
    }
}
