﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwoDrive.WebApi.Models
{
    public class TopWriterModel
    {
        public string Username { get; set; }

        public int FileCount { get; set; }
    }
}
