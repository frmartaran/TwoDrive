﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TwoDrive.Importer.Interface
{
    public class ImportingParameters
    {
        public string Path { get; set; }

        public ParameterDictionary ExtraParameters { get; set; }

    }
}
